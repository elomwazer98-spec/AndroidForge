package com.jusquoupeux.tuall;
import android.app.Activity; import android.os.Bundle; import android.webkit.*; import android.view.*; import android.widget.*;
import com.google.android.gms.ads.*;
public class MainActivity extends Activity {
 public void onCreate(Bundle b){super.onCreate(b); MobileAds.initialize(this,s->{});
 LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
 WebView w=new WebView(this); w.setWebViewClient(new WebViewClient()); w.getSettings().setJavaScriptEnabled(true); w.getSettings().setDomStorageEnabled(true); w.loadUrl("file:///android_asset/index.html");
 root.addView(w,new LinearLayout.LayoutParams(-1,0,1));
 AdView ad=new AdView(this); ad.setAdSize(AdSize.BANNER); ad.setAdUnitId("ca-app-pub-3940256099942544/6300978111"); ad.loadAd(new AdRequest.Builder().build());
 root.addView(ad,new LinearLayout.LayoutParams(-1,-2)); setContentView(root); }
}
